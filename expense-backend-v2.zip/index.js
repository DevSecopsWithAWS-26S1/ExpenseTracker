const app = require('./src/app');

const port = Number(process.env.PORT) || 8080;

app.listen(port, () => {
    console.log(`Expense API listening on port ${port}`);
});
