CREATE DATABASE IF NOT EXISTS transactions;
USE transactions;

CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    amount INT,
    description VARCHAR(255)
);

CREATE USER IF NOT EXISTS 'expense'@'%' IDENTIFIED BY 'ExpenseApp@1';
REVOKE ALL PRIVILEGES ON transactions.* FROM 'expense'@'%';
GRANT SELECT, INSERT, DELETE ON transactions.* TO 'expense'@'%';
FLUSH PRIVILEGES;
