const database = require('../config/database');

async function addTransaction(amount, description) {
    const [result] = await database.execute(
        'INSERT INTO transactions (amount, description) VALUES (?, ?)',
        [amount, description]
    );

    return result.insertId;
}

async function getAllTransactions() {
    const [rows] = await database.query(
        'SELECT id, amount, description FROM transactions ORDER BY id'
    );

    return rows;
}

async function findTransactionById(id) {
    const [rows] = await database.execute(
        'SELECT id, amount, description FROM transactions WHERE id = ?',
        [id]
    );

    return rows[0] || null;
}

async function deleteAllTransactions() {
    await database.query('DELETE FROM transactions');
}

async function deleteTransactionById(id) {
    const [result] = await database.execute(
        'DELETE FROM transactions WHERE id = ?',
        [id]
    );

    return result.affectedRows;
}

module.exports = {
    addTransaction,
    getAllTransactions,
    findTransactionById,
    deleteAllTransactions,
    deleteTransactionById
};
