const transactionService = require('../services/transactionService');

function createRequestError(message, statusCode) {
    const error = new Error(message);
    error.statusCode = statusCode;
    return error;
}

function getTransactionId(value) {
    const id = Number(value);

    if (!Number.isSafeInteger(id) || id < 1) {
        throw createRequestError('A positive transaction ID is required.', 400);
    }

    return id;
}

async function getHealth(req, res) {
    res.json('This is the health check');
}

async function getAllTransactions(req, res) {
    const result = await transactionService.getAllTransactions();
    res.json({ result });
}

async function addTransaction(req, res) {
    const rawAmount = req.body?.amount;
    const amount = Number(rawAmount);
    const { desc } = req.body || {};

    if (
        rawAmount === undefined ||
        rawAmount === null ||
        rawAmount === '' ||
        !Number.isSafeInteger(amount) ||
        typeof desc !== 'string'
    ) {
        throw createRequestError('Provide a whole-number amount and a description.', 400);
    }

    await transactionService.addTransaction(amount, desc);
    res.json({ message: 'added transaction successfully' });
}

async function deleteAllTransactions(req, res) {
    await transactionService.deleteAllTransactions();
    res.json({ message: 'delete function execution finished.' });
}

async function deleteTransactionById(req, res) {
    const id = getTransactionId(req.params.id ?? req.body?.id);
    const deletedRows = await transactionService.deleteTransactionById(id);

    if (deletedRows === 0) {
        throw createRequestError('Transaction not found.', 404);
    }

    res.json({ message: `transaction with id ${id} seemingly deleted` });
}

async function getTransactionById(req, res) {
    const id = getTransactionId(req.body?.id ?? req.query.id);
    const transaction = await transactionService.findTransactionById(id);

    if (!transaction) {
        throw createRequestError('Transaction not found.', 404);
    }

    res.json({
        id: transaction.id,
        amount: transaction.amount,
        desc: transaction.description
    });
}

module.exports = {
    getHealth,
    getAllTransactions,
    addTransaction,
    deleteAllTransactions,
    deleteTransactionById,
    getTransactionById
};
