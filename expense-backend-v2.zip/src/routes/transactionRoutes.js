const express = require('express');
const transactionController = require('../controllers/transactionController');

const router = express.Router();

function asyncHandler(handler) {
    return (req, res, next) => {
        Promise.resolve(handler(req, res, next)).catch(next);
    };
}

router.get('/health', asyncHandler(transactionController.getHealth));
router.get('/transaction', asyncHandler(transactionController.getAllTransactions));
router.post('/transaction', asyncHandler(transactionController.addTransaction));
router.delete('/transaction', asyncHandler(transactionController.deleteAllTransactions));
router.delete('/transaction/id', asyncHandler(transactionController.deleteTransactionById));
router.delete('/transaction/:id', asyncHandler(transactionController.deleteTransactionById));
router.get('/transaction/id', asyncHandler(transactionController.getTransactionById));

module.exports = router;
